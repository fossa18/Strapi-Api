module.exports = {
  displayName: '.github',
};
