'use strict';

module.exports = {
  coverageDirectory: '<rootDir>/coverage',
  projects: ['<rootDir>/packages/**/jest.config.js', '<rootDir>/.github'],
};
