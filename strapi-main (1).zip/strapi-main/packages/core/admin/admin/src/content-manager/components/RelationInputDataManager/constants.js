export const PUBLICATION_STATES = {
  DRAFT: 'draft',
  PUBLISHED: 'published',
};

export const RELATIONS_TO_DISPLAY = 5;

export const SEARCH_RESULTS_TO_DISPLAY = 10;
