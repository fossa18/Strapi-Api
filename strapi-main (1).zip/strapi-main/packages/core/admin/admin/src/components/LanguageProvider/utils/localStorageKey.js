const localStorageKey = 'strapi-admin-language';

export default localStorageKey;
