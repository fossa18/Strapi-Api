---
title: Code of conduct
hide_title: true
---

```mdx-code-block
import CodeOfConduct, {toc as CodeOfConductTOC} from "@site/../CODE_OF_CONDUCT.md"

<CodeOfConduct />

export const toc = CodeOfConductTOC;
```
