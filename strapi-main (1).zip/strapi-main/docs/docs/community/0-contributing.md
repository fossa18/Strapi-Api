---
title: Contributing
hide_title: true
---

```mdx-code-block
import Contributing, {toc as ContributingTOC} from "@site/../CONTRIBUTING.md"

<Contributing />

export const toc = ContributingTOC;
```
