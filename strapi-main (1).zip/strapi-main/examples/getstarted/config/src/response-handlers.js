'use strict';

module.exports = {
  404: async (/* ctx */) => {
    // return ctx.notFound('My custom message 404');
  },
};
