'use strict';

module.exports = () => {
  return (ctx, next) => next();
};
