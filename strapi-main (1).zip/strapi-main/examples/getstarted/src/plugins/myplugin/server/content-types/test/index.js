'use strict';

const schema = require('./schema');

module.exports = {
  schema,
};
