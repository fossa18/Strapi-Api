/**
 *
 * PluginIcon
 *
 */

import React from 'react';
import { Puzzle } from '@strapi/icons';

const PluginIcon = () => <Puzzle />;

export default PluginIcon;
