module.exports = {
  beforeUpdate() {
    const ctx = strapi.requestContext.get();
  },
};
